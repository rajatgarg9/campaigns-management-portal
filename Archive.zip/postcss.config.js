module.exports = {
  plugins: [
    require('stylelint')({
      failOnError: true,
      failOnWarning: true
    }),
    require('autoprefixer')
  ]
};
